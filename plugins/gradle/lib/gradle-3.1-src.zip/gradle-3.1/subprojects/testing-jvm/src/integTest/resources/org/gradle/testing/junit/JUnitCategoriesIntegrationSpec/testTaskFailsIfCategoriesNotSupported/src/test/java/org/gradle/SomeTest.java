package org.gradle;

import org.junit.Test;

public class SomeTest {
    @Test
    public void ok() {
    }

    public void helpermethod() {
    }
}
