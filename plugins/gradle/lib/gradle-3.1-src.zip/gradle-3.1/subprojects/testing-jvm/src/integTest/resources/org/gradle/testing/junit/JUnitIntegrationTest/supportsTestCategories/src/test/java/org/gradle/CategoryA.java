package org.gradle;

public interface CategoryA {
}
