import org.junit.Test;

public class Ok {
    @Test
    public void ok() {
    }
}