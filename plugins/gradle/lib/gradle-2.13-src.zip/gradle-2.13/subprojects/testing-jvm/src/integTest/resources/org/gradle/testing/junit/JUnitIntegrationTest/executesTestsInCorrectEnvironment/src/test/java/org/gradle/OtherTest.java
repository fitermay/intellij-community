package org.gradle;

public class OtherTest {
    @org.junit.Test
    public void ok() throws Exception {
    }
}