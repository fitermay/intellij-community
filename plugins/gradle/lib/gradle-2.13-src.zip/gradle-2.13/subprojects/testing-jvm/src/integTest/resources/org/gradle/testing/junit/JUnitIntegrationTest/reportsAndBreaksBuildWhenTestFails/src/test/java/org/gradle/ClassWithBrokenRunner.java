package org.gradle;

import org.junit.runner.RunWith;

@RunWith(BrokenRunner.class)
public class ClassWithBrokenRunner {
}
