package org.gradle;

import org.junit.Test;

public class Test2 {
    @Test
    public void ok() {
    }
}
