package org.gradle;

public interface CategoryC {
}
