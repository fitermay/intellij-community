package org.gradle;

import org.junit.Test;

public class SomeTestClass {
    @Test
    public void ok1() {
    }

    @Test
    public void ok2() {
    }
}